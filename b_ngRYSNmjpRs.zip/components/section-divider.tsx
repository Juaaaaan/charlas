"use client"

import { motion } from "framer-motion"

export function SectionDivider() {
  return (
    <motion.div
      className="flex justify-center py-8"
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex items-center gap-4">
        <div className="w-2 h-2 rounded-full bg-primary/30" />
        <div className="w-24 h-px bg-gradient-to-r from-primary/30 via-primary/10 to-transparent" />
      </div>
    </motion.div>
  )
}
