"use client"

import { motion } from "framer-motion"
import { Database, Cpu, Box, MessageSquare } from "lucide-react"

const flowSteps = [
  { icon: Database, label: "Datos", sublabel: "Texto de internet" },
  { icon: Cpu, label: "Entrenamiento", sublabel: "Ajuste de pesos" },
  { icon: Box, label: "Modelo", sublabel: "Red neuronal" },
  { icon: MessageSquare, label: "Respuesta", sublabel: "Texto generado" }
]

export function ModelLLMSection() {
  return (
    <section className="min-h-screen flex items-center py-32 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-secondary/20 via-background to-background" />
      
      <div className="relative z-10 max-w-6xl mx-auto px-6 w-full">
        <motion.div
          className="mb-20 max-w-3xl"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-primary text-sm font-medium tracking-[0.2em] uppercase mb-4 block">
            Conceptos clave
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-8 text-balance">
            Qué es un modelo y qué es un LLM
          </h2>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 mb-20">
          {/* Model definition */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.5 }}
          >
            <div className="p-8 rounded-2xl bg-card border border-border/50 h-full">
              <h3 className="text-2xl font-semibold text-foreground mb-4">
                Un modelo
              </h3>
              <p className="text-muted-foreground leading-relaxed mb-6">
                Es una estructura matemática que ha aprendido patrones de los datos. No programa reglas: descubre relaciones.
              </p>
              <div className="flex items-center gap-3 p-4 rounded-xl bg-secondary/50">
                <span className="text-3xl font-mono text-primary">f(x)</span>
                <span className="text-muted-foreground">→</span>
                <span className="text-foreground">Entrada → Predicción</span>
              </div>
            </div>
          </motion.div>

          {/* LLM definition */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <div className="p-8 rounded-2xl bg-primary/5 border border-primary/20 h-full">
              <h3 className="text-2xl font-semibold text-primary mb-4">
                Un LLM
              </h3>
              <p className="text-muted-foreground leading-relaxed mb-6">
                Large Language Model. Un modelo entrenado con texto masivo que predice qué palabra viene después, con resultados sorprendentes.
              </p>
              <div className="flex items-center gap-3 p-4 rounded-xl bg-primary/10">
                <span className="text-foreground font-medium">{"\"La capital de Francia es...\""}</span>
                <span className="text-primary">→</span>
                <span className="text-primary font-semibold">{"\"París\""}</span>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Flow diagram */}
        <motion.div
          className="relative"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-50px" }}
          transition={{ duration: 0.6 }}
        >
          <div className="p-8 rounded-2xl bg-card border border-border/50">
            <h4 className="text-lg font-medium text-muted-foreground mb-8 text-center">
              Ciclo de vida de un modelo
            </h4>
            
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 md:gap-2">
              {flowSteps.map((step, index) => (
                <div key={step.label} className="flex items-center gap-4 md:gap-2 flex-1">
                  <motion.div
                    className="flex flex-col items-center text-center min-w-[100px]"
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                  >
                    <div className={`
                      w-14 h-14 rounded-xl flex items-center justify-center mb-3
                      ${index === 2 ? 'bg-primary/20' : 'bg-secondary'}
                    `}>
                      <step.icon className={`w-7 h-7 ${index === 2 ? 'text-primary' : 'text-muted-foreground'}`} />
                    </div>
                    <span className={`font-medium ${index === 2 ? 'text-primary' : 'text-foreground'}`}>
                      {step.label}
                    </span>
                    <span className="text-xs text-muted-foreground mt-1">
                      {step.sublabel}
                    </span>
                  </motion.div>
                  
                  {index < flowSteps.length - 1 && (
                    <div className="hidden md:flex items-center flex-1 px-2">
                      <div className="h-px flex-1 bg-border" />
                      <div className="w-2 h-2 border-t border-r border-border rotate-45 -ml-1" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
