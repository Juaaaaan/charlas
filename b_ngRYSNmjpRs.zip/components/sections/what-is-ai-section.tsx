"use client"

import { motion } from "framer-motion"
import { Settings, BarChart3, Brain } from "lucide-react"

const comparisons = [
  {
    icon: Settings,
    title: "Automatización",
    description: "Reglas fijas, comportamiento predecible",
    example: "Si X, entonces Y",
    color: "text-muted-foreground"
  },
  {
    icon: BarChart3,
    title: "Analítica",
    description: "Patrones en datos, insights históricos",
    example: "Estadística avanzada",
    color: "text-muted-foreground"
  },
  {
    icon: Brain,
    title: "Inteligencia Artificial",
    description: "Aprende, genera, razona, se adapta",
    example: "Comportamiento emergente",
    color: "text-primary"
  }
]

export function WhatIsAISection() {
  return (
    <section className="min-h-screen flex items-center py-32 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-secondary/10 to-background" />
      
      <div className="relative z-10 max-w-6xl mx-auto px-6 w-full">
        <motion.div
          className="mb-20 max-w-3xl"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-primary text-sm font-medium tracking-[0.2em] uppercase mb-4 block">
            Fundamentos
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-8 text-balance">
            ¿Qué es realmente la IA?
          </h2>
          <p className="text-xl text-muted-foreground leading-relaxed">
            Sistemas capaces de realizar tareas que normalmente requieren inteligencia humana: comprender, aprender, razonar y generar.
          </p>
        </motion.div>

        {/* Visual comparison */}
        <div className="relative">
          {/* Connection line */}
          <div className="hidden md:block absolute top-1/2 left-0 right-0 h-px bg-gradient-to-r from-transparent via-border to-transparent -translate-y-1/2" />
          
          <div className="grid md:grid-cols-3 gap-6 md:gap-4">
            {comparisons.map((item, index) => (
              <motion.div
                key={item.title}
                className="relative"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.5, delay: index * 0.15 }}
              >
                <div className={`
                  relative p-8 rounded-2xl border transition-all duration-500
                  ${index === 2 
                    ? 'bg-primary/5 border-primary/30' 
                    : 'bg-card border-border/50'}
                `}>
                  <div className="flex flex-col items-center text-center">
                    <div className={`
                      w-16 h-16 rounded-2xl flex items-center justify-center mb-6
                      ${index === 2 ? 'bg-primary/20' : 'bg-secondary'}
                    `}>
                      <item.icon className={`w-8 h-8 ${item.color}`} />
                    </div>
                    
                    <h3 className={`text-xl font-semibold mb-3 ${index === 2 ? 'text-primary' : 'text-foreground'}`}>
                      {item.title}
                    </h3>
                    
                    <p className="text-muted-foreground text-sm mb-4 leading-relaxed">
                      {item.description}
                    </p>
                    
                    <span className={`
                      text-xs font-mono px-3 py-1.5 rounded-full
                      ${index === 2 ? 'bg-primary/10 text-primary' : 'bg-secondary text-muted-foreground'}
                    `}>
                      {item.example}
                    </span>
                  </div>
                </div>
                
                {/* Arrow indicator for last item */}
                {index === 2 && (
                  <div className="hidden md:block absolute -left-4 top-1/2 -translate-y-1/2 -translate-x-full">
                    <div className="w-8 h-px bg-primary/50" />
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
