"use client"

import { motion } from "framer-motion"
import { Zap, Users, TrendingUp, Target } from "lucide-react"

const reasons = [
  {
    icon: Zap,
    title: "Más capacidad",
    description: "Modelos más potentes, más rápidos y más accesibles que nunca"
  },
  {
    icon: Users,
    title: "Más acceso",
    description: "APIs abiertas, interfaces amigables y ecosistema maduro"
  },
  {
    icon: TrendingUp,
    title: "Más adopción",
    description: "Integración real en productos, procesos y decisiones"
  },
  {
    icon: Target,
    title: "Más impacto",
    description: "Resultados medibles en productividad y valor de negocio"
  }
]

export function WhyNowSection() {
  return (
    <section className="min-h-screen flex items-center py-32 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-secondary/20 via-background to-background" />
      
      <div className="relative z-10 max-w-6xl mx-auto px-6 w-full">
        <motion.div
          className="mb-20"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-primary text-sm font-medium tracking-[0.2em] uppercase mb-4 block">
            Contexto
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground text-balance">
            ¿Por qué hablamos de IA ahora?
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6">
          {reasons.map((reason, index) => (
            <motion.div
              key={reason.title}
              className="group relative"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="relative h-full p-8 rounded-2xl bg-card border border-border/50 hover:border-primary/30 transition-all duration-500">
                {/* Subtle hover glow */}
                <div className="absolute inset-0 rounded-2xl bg-primary/0 group-hover:bg-primary/5 transition-colors duration-500" />
                
                <div className="relative z-10">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors duration-500">
                    <reason.icon className="w-6 h-6 text-primary" />
                  </div>
                  
                  <h3 className="text-2xl font-semibold text-foreground mb-3">
                    {reason.title}
                  </h3>
                  
                  <p className="text-muted-foreground leading-relaxed">
                    {reason.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
