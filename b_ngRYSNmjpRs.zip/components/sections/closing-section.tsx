"use client"

import { motion } from "framer-motion"
import { Lightbulb, Target, Compass } from "lucide-react"

const keyTakeaways = [
  {
    icon: Lightbulb,
    title: "Entiende qué es",
    description: "Un modelo que predice texto basándose en patrones aprendidos"
  },
  {
    icon: Target,
    title: "Conoce sus límites",
    description: "No es magia. Alucina, sesga, y necesita contexto"
  },
  {
    icon: Compass,
    title: "Aplícala con criterio",
    description: "El valor está en usarla bien, no en usarla más"
  }
]

const upcomingTopics = [
  "Prompting avanzado",
  "RAG y documentos",
  "Workflows",
  "Agentes"
]

export function ClosingSection() {
  return (
    <section className="min-h-screen flex items-center py-32 relative overflow-hidden">
      {/* Special closing background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 to-background" />
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-primary/5 rounded-full blur-3xl" />
      
      <div className="relative z-10 max-w-6xl mx-auto px-6 w-full">
        <motion.div
          className="mb-20 text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-primary text-sm font-medium tracking-[0.2em] uppercase mb-4 block">
            Para recordar
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-8 text-balance">
            3 ideas clave
          </h2>
        </motion.div>

        {/* Key takeaways */}
        <div className="grid md:grid-cols-3 gap-6 mb-24">
          {keyTakeaways.map((item, index) => (
            <motion.div
              key={item.title}
              className="text-center"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: index * 0.15 }}
            >
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-6">
                <item.icon className="w-8 h-8 text-primary" />
              </div>
              
              <h4 className="text-xl font-semibold text-foreground mb-3">
                {item.title}
              </h4>
              
              <p className="text-muted-foreground leading-relaxed">
                {item.description}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Final quote */}
        <motion.div
          className="text-center mb-24"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-50px" }}
          transition={{ duration: 0.6 }}
        >
          <div className="max-w-3xl mx-auto">
            <div className="h-px w-24 bg-gradient-to-r from-transparent via-primary to-transparent mx-auto mb-12" />
            
            <blockquote className="text-2xl md:text-3xl lg:text-4xl font-light text-foreground leading-relaxed mb-8 text-balance">
              {"\"La IA no va a sustituirte. Pero alguien que sepa usarla, quizá sí.\""}
            </blockquote>
            
            <div className="h-px w-24 bg-gradient-to-r from-transparent via-primary to-transparent mx-auto" />
          </div>
        </motion.div>

        {/* Teaser for next sessions */}
        <motion.div
          className="p-8 rounded-2xl bg-card border border-border/50 text-center"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-50px" }}
          transition={{ duration: 0.6 }}
        >
          <p className="text-muted-foreground mb-6">
            Próximamente
          </p>
          
          <div className="flex flex-wrap justify-center gap-3">
            {upcomingTopics.map((topic, index) => (
              <motion.span
                key={topic}
                className="px-4 py-2 rounded-full bg-secondary text-foreground text-sm font-medium"
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3 + index * 0.1 }}
              >
                {topic}
              </motion.span>
            ))}
          </div>
        </motion.div>

        {/* Thank you */}
        <motion.div
          className="mt-20 text-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
        >
          <p className="text-muted-foreground text-lg">
            Gracias por vuestra atención
          </p>
        </motion.div>
      </div>
    </section>
  )
}
