"use client"

import { motion } from "framer-motion"
import { Ghost, Scale, Clock, HelpCircle, AlertTriangle } from "lucide-react"

const limitations = [
  {
    icon: Ghost,
    title: "Alucinaciones",
    description: "Inventa información con total convicción",
    detail: "Puede generar datos, citas o hechos completamente falsos"
  },
  {
    icon: Scale,
    title: "Sesgos",
    description: "Refleja sesgos de los datos de entrenamiento",
    detail: "Puede reproducir prejuicios culturales, de género o sociales"
  },
  {
    icon: Clock,
    title: "Conocimiento limitado",
    description: "Su conocimiento tiene fecha de corte",
    detail: "No sabe lo que ocurrió después de su entrenamiento"
  },
  {
    icon: HelpCircle,
    title: "Sin contexto real",
    description: "No conoce tu empresa ni tu situación",
    detail: "Necesita que le proporciones el contexto específico"
  },
  {
    icon: AlertTriangle,
    title: "Confianza excesiva",
    description: "Suena convincente aunque esté equivocado",
    detail: "La seguridad en la respuesta no indica veracidad"
  }
]

export function LimitationsSection() {
  return (
    <section className="min-h-screen flex items-center py-32 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-secondary/10 to-background" />
      
      <div className="relative z-10 max-w-6xl mx-auto px-6 w-full">
        <motion.div
          className="mb-20 max-w-3xl"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-primary text-sm font-medium tracking-[0.2em] uppercase mb-4 block">
            Realidad
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-8 text-balance">
            Limitaciones reales
          </h2>
          <p className="text-xl text-muted-foreground leading-relaxed">
            La IA es útil, no mágica. Conocer sus límites es clave para usarla bien.
          </p>
        </motion.div>

        {/* Limitations grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {limitations.map((item, index) => (
            <motion.div
              key={item.title}
              className={`
                group relative p-6 rounded-2xl border transition-all duration-300
                ${index === 0 
                  ? 'bg-destructive/5 border-destructive/20 hover:border-destructive/40 md:col-span-2 lg:col-span-1' 
                  : 'bg-card border-border/50 hover:border-muted-foreground/30'}
              `}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-30px" }}
              transition={{ duration: 0.4, delay: index * 0.08 }}
            >
              <div className={`
                w-10 h-10 rounded-xl flex items-center justify-center mb-4
                ${index === 0 ? 'bg-destructive/10' : 'bg-secondary'}
              `}>
                <item.icon className={`w-5 h-5 ${index === 0 ? 'text-destructive' : 'text-muted-foreground'}`} />
              </div>
              
              <h4 className={`text-lg font-semibold mb-2 ${index === 0 ? 'text-destructive' : 'text-foreground'}`}>
                {item.title}
              </h4>
              
              <p className="text-muted-foreground text-sm mb-3">
                {item.description}
              </p>
              
              <p className="text-xs text-muted-foreground/70">
                {item.detail}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Key message */}
        <motion.div
          className="mt-12 text-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
        >
          <p className="text-lg text-muted-foreground">
            <span className="text-foreground font-medium">Regla de oro:</span> Verifica siempre lo que importa
          </p>
        </motion.div>
      </div>
    </section>
  )
}
