"use client"

import { motion } from "framer-motion"

const tokens = ["El", "gato", "está", "en", "el", "___"]
const tokenColors = [
  "bg-secondary text-muted-foreground",
  "bg-secondary text-muted-foreground",
  "bg-secondary text-muted-foreground",
  "bg-secondary text-muted-foreground",
  "bg-secondary text-muted-foreground",
  "bg-primary/20 text-primary border-2 border-primary/40"
]

const concepts = [
  {
    term: "Token",
    definition: "Unidad mínima de texto que el modelo procesa",
    example: "\"inteligencia\" → [\"inteli\", \"gencia\"]"
  },
  {
    term: "Contexto",
    definition: "Todo el texto previo que el modelo considera",
    example: "La conversación completa hasta ahora"
  },
  {
    term: "Ventana",
    definition: "Límite de tokens que el modelo puede procesar",
    example: "32K, 128K, 200K tokens..."
  },
  {
    term: "Predicción",
    definition: "El modelo calcula probabilidades para el siguiente token",
    example: "tejado: 45%, sofá: 30%, jardín: 15%..."
  }
]

export function HowLLMWorksSection() {
  return (
    <section className="min-h-screen flex items-center py-32 relative overflow-hidden">
      {/* Special background for this key section */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 to-background" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(100,150,255,0.08),transparent_70%)]" />
      
      <div className="relative z-10 max-w-6xl mx-auto px-6 w-full">
        <motion.div
          className="mb-16 max-w-3xl"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-primary text-sm font-medium tracking-[0.2em] uppercase mb-4 block">
            En profundidad
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-8 text-balance">
            Cómo funciona un LLM
          </h2>
          <p className="text-xl text-muted-foreground leading-relaxed">
            Predice el siguiente token basándose en todo el contexto anterior. Así de simple. Así de potente.
          </p>
        </motion.div>

        {/* Token visualization */}
        <motion.div
          className="mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-50px" }}
          transition={{ duration: 0.6 }}
        >
          <div className="p-8 md:p-12 rounded-2xl bg-card border border-border/50 overflow-hidden">
            <h4 className="text-lg font-medium text-muted-foreground mb-8 text-center">
              Predicción del siguiente token
            </h4>
            
            {/* Token sequence */}
            <div className="flex flex-wrap justify-center gap-3 mb-10">
              {tokens.map((token, index) => (
                <motion.div
                  key={index}
                  className={`
                    px-5 py-3 rounded-xl font-mono text-lg
                    ${tokenColors[index]}
                  `}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                >
                  {token}
                </motion.div>
              ))}
            </div>

            {/* Prediction probabilities */}
            <motion.div
              className="flex flex-col items-center"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.6 }}
            >
              <div className="h-8 w-px bg-gradient-to-b from-primary/50 to-transparent mb-4" />
              
              <div className="flex flex-wrap justify-center gap-4">
                {[
                  { word: "tejado", prob: "45%" },
                  { word: "sofá", prob: "30%" },
                  { word: "jardín", prob: "15%" },
                  { word: "...", prob: "" }
                ].map((item, index) => (
                  <div
                    key={item.word}
                    className={`
                      px-4 py-2 rounded-lg text-sm
                      ${index === 0 ? 'bg-primary/20 text-primary font-medium' : 'bg-secondary text-muted-foreground'}
                    `}
                  >
                    {item.word} {item.prob && <span className="opacity-60">{item.prob}</span>}
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </motion.div>

        {/* Concepts grid */}
        <div className="grid md:grid-cols-2 gap-4">
          {concepts.map((concept, index) => (
            <motion.div
              key={concept.term}
              className="p-6 rounded-2xl bg-card border border-border/50 hover:border-primary/30 transition-colors duration-300"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-30px" }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
            >
              <h4 className="text-lg font-semibold text-primary mb-2">
                {concept.term}
              </h4>
              <p className="text-muted-foreground text-sm mb-3">
                {concept.definition}
              </p>
              <code className="text-xs font-mono text-foreground/60 bg-secondary px-2 py-1 rounded">
                {concept.example}
              </code>
            </motion.div>
          ))}
        </div>

        {/* Training vs Inference */}
        <motion.div
          className="mt-12 p-8 rounded-2xl border border-primary/20 bg-primary/5"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-50px" }}
          transition={{ duration: 0.6 }}
        >
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h4 className="text-xl font-semibold text-foreground mb-3 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-muted-foreground" />
                Entrenamiento
              </h4>
              <p className="text-muted-foreground">
                Meses de computación masiva. Ajusta billones de parámetros. Se hace una vez. Coste: millones.
              </p>
            </div>
            <div>
              <h4 className="text-xl font-semibold text-primary mb-3 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-primary" />
                Inferencia
              </h4>
              <p className="text-muted-foreground">
                Usar el modelo ya entrenado. Generar respuestas. Milisegundos por token. Es lo que usamos.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
