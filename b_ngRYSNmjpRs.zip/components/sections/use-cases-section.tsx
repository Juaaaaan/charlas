"use client"

import { motion } from "framer-motion"
import { Sparkles, MessageSquare, FileSearch, ListFilter, Code } from "lucide-react"

const useCases = [
  {
    icon: Sparkles,
    title: "Productividad personal",
    description: "Redacción, síntesis, lluvia de ideas, revisión",
    category: "Negocio"
  },
  {
    icon: MessageSquare,
    title: "Asistentes internos",
    description: "Chatbots que responden sobre políticas, procesos, FAQ",
    category: "Negocio"
  },
  {
    icon: FileSearch,
    title: "Búsqueda inteligente",
    description: "Encontrar información en documentación interna",
    category: "Tecnología"
  },
  {
    icon: ListFilter,
    title: "Resumen y clasificación",
    description: "Procesar emails, tickets, feedback de forma automática",
    category: "Negocio"
  },
  {
    icon: Code,
    title: "Desarrollo de software",
    description: "Generación de código, debugging, documentación",
    category: "Tecnología"
  }
]

export function UseCasesSection() {
  return (
    <section className="min-h-screen flex items-center py-32 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 to-background" />
      
      <div className="relative z-10 max-w-6xl mx-auto px-6 w-full">
        <motion.div
          className="mb-20 max-w-3xl"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-primary text-sm font-medium tracking-[0.2em] uppercase mb-4 block">
            Aplicación
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-8 text-balance">
            Casos de uso reales
          </h2>
          <p className="text-xl text-muted-foreground leading-relaxed">
            Donde la IA ya está generando valor en empresas reales.
          </p>
        </motion.div>

        {/* Use cases grid - bento style */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {useCases.map((useCase, index) => (
            <motion.div
              key={useCase.title}
              className={`
                group relative p-8 rounded-2xl border border-border/50 hover:border-primary/30 transition-all duration-500
                ${index === 0 ? 'md:col-span-2 lg:col-span-1 lg:row-span-2' : ''}
                ${index === 0 ? 'bg-primary/5' : 'bg-card'}
              `}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-30px" }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
            >
              {/* Hover glow */}
              <div className="absolute inset-0 rounded-2xl bg-primary/0 group-hover:bg-primary/5 transition-colors duration-500" />
              
              <div className="relative z-10 h-full flex flex-col">
                <div className="flex items-center justify-between mb-6">
                  <div className={`
                    w-12 h-12 rounded-xl flex items-center justify-center
                    ${index === 0 ? 'bg-primary/20' : 'bg-secondary group-hover:bg-primary/10'}
                    transition-colors duration-500
                  `}>
                    <useCase.icon className={`w-6 h-6 ${index === 0 ? 'text-primary' : 'text-muted-foreground group-hover:text-primary'} transition-colors duration-500`} />
                  </div>
                  
                  <span className={`
                    text-xs font-medium px-3 py-1 rounded-full
                    ${useCase.category === 'Tecnología' ? 'bg-primary/10 text-primary' : 'bg-secondary text-muted-foreground'}
                  `}>
                    {useCase.category}
                  </span>
                </div>
                
                <h4 className={`text-xl font-semibold mb-3 ${index === 0 ? 'text-primary' : 'text-foreground'}`}>
                  {useCase.title}
                </h4>
                
                <p className="text-muted-foreground leading-relaxed flex-1">
                  {useCase.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom note */}
        <motion.div
          className="mt-12 p-6 rounded-2xl bg-card border border-border/50 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
        >
          <p className="text-muted-foreground">
            El valor no está en la tecnología, sino en <span className="text-primary font-medium">cómo se aplica</span> al contexto específico.
          </p>
        </motion.div>
      </div>
    </section>
  )
}
