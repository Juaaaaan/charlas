"use client"

import { HeroSection } from "@/components/sections/hero-section"
import { WhyNowSection } from "@/components/sections/why-now-section"
import { WhatIsAISection } from "@/components/sections/what-is-ai-section"
import { AIEvolutionSection } from "@/components/sections/ai-evolution-section"
import { ModelLLMSection } from "@/components/sections/model-llm-section"
import { HowLLMWorksSection } from "@/components/sections/how-llm-works-section"
import { LimitationsSection } from "@/components/sections/limitations-section"
import { UseCasesSection } from "@/components/sections/use-cases-section"
import { ClosingSection } from "@/components/sections/closing-section"
import { SectionDivider } from "@/components/section-divider"

export default function Home() {
  return (
    <main className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <HeroSection />
      <SectionDivider />
      <WhyNowSection />
      <SectionDivider />
      <WhatIsAISection />
      <SectionDivider />
      <AIEvolutionSection />
      <SectionDivider />
      <ModelLLMSection />
      <SectionDivider />
      <HowLLMWorksSection />
      <SectionDivider />
      <LimitationsSection />
      <SectionDivider />
      <UseCasesSection />
      <SectionDivider />
      <ClosingSection />
    </main>
  )
}
